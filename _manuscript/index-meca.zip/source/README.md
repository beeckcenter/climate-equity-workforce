# Equitable workforce transition to green jobs
This repository contains a visual essay, analysis, and dataset(s) on the equitable workforce transition to green jobs in the US, with a focus on St. Paul, Minnesota.
